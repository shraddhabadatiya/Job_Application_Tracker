package com.mycompany.Dashboard;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SuccessfullApplications {
    private static DefaultTableModel tableModel;
    private static JTable table;

    public static void main(String[] args) {
       JFrame frame = new JFrame("Rejected Applications");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180)); // Steel Blue
        JLabel headerLabel = new JLabel("Rejected Applications");
        headerLabel.setFont(new Font("Serif", Font.BOLD, 36));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        frame.add(headerPanel, BorderLayout.NORTH);

        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(70, 130, 180)); // Steel Blue
        JLabel footerLabel = new JLabel("© 2025 Job Application Tracker. All Rights Reserved.", JLabel.CENTER);
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);
        frame.add(footerPanel, BorderLayout.SOUTH);

        String[] columns = {"Company Name", "Role", "Check Availability", "Reapply"};
        Object[][] data = {
                {"TechMahindra", "Software Engineer", getRandomStatus(), "Reapply"},
                {"Delloite", "Web Developer", getRandomStatus(), "Reapply"},
                {"IBM", "Data Analyst", getRandomStatus(), "Reapply"},
                 {"Sony", "Marketing Leader", getRandomStatus(), "Reapply"},
                 {"INNODATA", "Data Scientist", getRandomStatus(), "Reapply"}
        };

        DefaultTableModel tableModel = new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3; 
            }
        };

        JTable table = new JTable(tableModel);

        Font headerFont = new Font("Verdana", Font.BOLD, 16);
        Font cellFont = new Font("Arial", Font.PLAIN, 14); 
        table.getTableHeader().setFont(headerFont);
        table.setFont(cellFont);
        table.setRowHeight(30);

        
        table.getColumn("Reapply").setCellRenderer((table1, value, isSelected, hasFocus, row, column) -> {
            String status = (String) table1.getValueAt(row, 2); 
            JButton reapplyButton = new JButton("Reapply");
            reapplyButton.setFont(new Font("SansSerif", Font.BOLD, 14));

          
            if ("Denied".equals(status)) {
                reapplyButton.setEnabled(false);
                reapplyButton.setBackground(Color.GRAY);
            } else {
                reapplyButton.setBackground(Color.cyan); // Green for active reapply
                reapplyButton.addActionListener(e -> {
                    String companyName = (String) table1.getValueAt(row, 0);
                    JOptionPane.showMessageDialog(frame, "Reapplying for the role at " + companyName);
                });
            }
            return reapplyButton;
        });

        table.getColumn("Reapply").setCellEditor(new DefaultCellEditor(new JTextField()));

        JScrollPane scrollPane = new JScrollPane(table);

        frame.add(scrollPane, BorderLayout.CENTER);
        
        frame.setVisible(true);
    }

    private static String getRandomStatus() {
        return Math.random() > 0.5 ? "Apply" : "Denied";
    }
}