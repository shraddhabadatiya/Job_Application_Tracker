package com.mycompany.pendingapplication;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.JTableHeader;

public class PendingApplication {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Pending Applications");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180)); 
        JLabel headerLabel = new JLabel("Pending Applications");
        headerLabel.setFont(new Font("Serif", Font.BOLD, 36));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        frame.add(headerPanel, BorderLayout.NORTH);
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(70, 130, 180)); // Steel Blue
        JLabel footerLabel = new JLabel("© 2025 Job Application Tracker. All Rights Reserved.", JLabel.CENTER);
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);
        frame.add(footerPanel,BorderLayout.SOUTH);
        


       
        String[] columns = {"Company Name", "Job Role", "Requirements", "Due Date", "Apply Link"};
        Object[][] data = {
                {"TechCorp", "Software Engineer", "Java, Spring Boot", "2025-01-31", "https://techcorp.com/apply"},
                {"DesignStudio", "Graphic Designer", "Photoshop, Illustrator", "2025-02-10", "https://designstudio.com/apply"},
                {"InnovateTech", "UI/UX Designer", "Figma, Adobe XD", "2025-02-20", "https://innovatetech.com/careers"},
                {"CodeFactory", "Full Stack Developer", "React, Node.js, MongoDB", "2025-03-05", "https://codefactory.com/jobs"},
                {"HealthPlus", "Data Scientist", "Python, Machine Learning, SQL", "2025-03-15", "https://healthplus.com/apply"}
        };

        
        DefaultTableModel tableModel = new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4; 
            }
        };

        JTable table = new JTable(tableModel);

        
        Font headerFont = new Font("Verdana", Font.BOLD, 16); 
        Font cellFont = new Font("Arial", Font.PLAIN, 14); 

        
        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setFont(headerFont);

        
        table.setFont(cellFont);
        table.setRowHeight(25); 

        
        table.getColumn("Apply Link").setCellRenderer((table1, value, isSelected, hasFocus, row, column) -> {
            JButton button = new JButton("Apply");
            button.setFont(new Font("SansSerif", Font.BOLD, 14)); // Button font
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String link = (String) table1.getValueAt(row, column);
                    openLink(link);
                }
            });
            return button;
        });

        table.getColumn("Apply Link").setCellEditor(new DefaultCellEditor(new JTextField()));

        
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Display Frame
        frame.setVisible(true);
    }

    private static void openLink(String url) {
        try {
            Desktop.getDesktop().browse(java.net.URI.create(url));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
