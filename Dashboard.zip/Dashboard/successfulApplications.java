package com.mycompany.DashBoard;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.TableRowSorter;

public class SuccessfullApplications {
    private static DefaultTableModel tableModel;
    private static JTable table;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Enhanced Applications");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180)); 
        JLabel headerLabel = new JLabel("Successful Applications");
        headerLabel.setFont(new Font("Serif", Font.BOLD, 36));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        frame.add(headerPanel, BorderLayout.NORTH);
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(70, 130, 180)); // Steel Blue
        JLabel footerLabel = new JLabel("© 2025 Job Application Tracker. All Rights Reserved.", JLabel.CENTER);
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);
        frame.add(footerPanel,BorderLayout.SOUTH);

        // Table Data
        String[] columns = {"Company Name", "Role", "Date Applied", "Resume", "Actions"};
        Object[][] data = {
                {"Accenture", "Software Engineer", "2025-01-10", "Uploaded", "Check | View"},
                {"DesignForp", "Graphic Designer", "2025-01-15", "Uploaded", "Check | View"},
                {"Barclays", "Data Analyst", "2025-01-20",  "Uploaded", "Check | View"},
                {"Wipro", "SDE Intern", "2025-01-22",  "Uploaded", "Check | View"},
                {"Google", "Technician ", "2025-01-05",  "Uploaded", "Check | View"}
                
        };

        tableModel = new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3 || column == 4 || column == 5 || row==4 ||row==5 ||row==6; // Editable for Status, Resume, and Actions
            }
        };

        table = new JTable(tableModel);

        Font headerFont = new Font("Verdana", Font.BOLD, 16);
        Font cellFont = new Font("Arial", Font.PLAIN, 14);
        table.getTableHeader().setFont(headerFont);
        table.setFont(cellFont);
        table.setRowHeight(30);
        table.getColumn("Actions").setCellRenderer((table1, value, isSelected, hasFocus, row, column) -> {
            JPanel panel = new JPanel(new GridLayout(1, 2, 5, 5));
            JButton checkButton = new JButton("Check");
            JButton viewButton = new JButton("View Resume");

            checkButton.setFont(new Font("SansSerif", Font.BOLD, 12));
            viewButton.setFont(new Font("SansSerif", Font.BOLD, 12));

            checkButton.addActionListener(e -> {
                String companyName = (String) table1.getValueAt(row, 0);
                JOptionPane.showMessageDialog(frame, "Checking status for " + companyName);
            });

            viewButton.addActionListener(e -> {
                String resumeFile = (String) table1.getValueAt(row, 4);
                if ("None".equals(resumeFile)) {
                    JOptionPane.showMessageDialog(frame, "No resume uploaded for this application.");
                } else {
                    JOptionPane.showMessageDialog(frame, "Opening resume: " + resumeFile);
                }
            });

            panel.add(checkButton);
            panel.add(viewButton);
            return panel;
        });

        table.getColumn("Actions").setCellEditor(new DefaultCellEditor(new JTextField()));

        // Scroll Pane for Table
        JScrollPane scrollPane = new JScrollPane(table);

        // Search Bar
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel searchLabel = new JLabel("Search Company:");
        JTextField searchField = new JTextField(20);
        searchField.setFont(cellFont);
        searchField.addActionListener(e -> {
            String query = searchField.getText().toLowerCase();
            filterTable(query);
        });
        searchPanel.add(searchLabel);
        searchPanel.add(searchField);

        // Upload Resume Button
        JButton uploadResumeButton = new JButton("Upload Resume");
        uploadResumeButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        uploadResumeButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(frame, "Please select a row to upload the resume.");
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                String selectedFile = fileChooser.getSelectedFile().getAbsolutePath();
                tableModel.setValueAt(selectedFile, selectedRow, 4);
                JOptionPane.showMessageDialog(frame, "Resume uploaded successfully!");
            }
        });

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        controlPanel.add(uploadResumeButton);

      //  frame.add(searchPanel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
      //  frame.add(controlPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    private static void filterTable(String query) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        sorter.setRowFilter(RowFilter.regexFilter(query, 0)); // Filter by Company Name (column 0)
    

       
    }
}
