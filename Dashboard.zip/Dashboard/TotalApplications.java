package com.mycompany.totalapplications1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
public class TotalApplications1 extends JFrame{
     private JTable applicationTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    
    public TotalApplications1(){
         setTitle("Total Applications");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLayout(new BorderLayout());
         JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180)); // Steel Blue
        JLabel headerLabel = new JLabel("Total Applications");
        headerLabel.setFont(new Font("Serif", Font.BOLD, 36));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Table Setup
        String[] columnNames = {"Company Name", "Status", "Last Date to Apply"};
        tableModel = new DefaultTableModel(columnNames, 0);
        applicationTable = new JTable(tableModel);

        // Adjust Font Style and Size for Table Header
        JTableHeader tableHeader = applicationTable.getTableHeader();
        tableHeader.setFont(new Font("Arial", Font.BOLD, 18)); // Header Font
        tableHeader.setBackground(Color.LIGHT_GRAY);
        tableHeader.setForeground(Color.BLACK);

        // Adjust Font Style and Size for Table Content
        applicationTable.setFont(new Font("Serif", Font.PLAIN, 16)); // Content Font
        applicationTable.setRowHeight(30); // Increase row height for better visibility

        // Center Align Content
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < applicationTable.getColumnCount(); i++) {
            applicationTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(applicationTable);

        // Adding some dummy data
        tableModel.addRow(new Object[]{"Accenture","Apply ","2025-01-31"});
        tableModel.addRow(new Object[]{"TCS", "Apply", "2025-02-20"});
        tableModel.addRow(new Object[]{"Wipro", "Apply", "2025-02-28"});
        tableModel.addRow(new Object[]{"DRDO", "Deneid", "2025-01-10"});
        tableModel.addRow(new Object[]{"Indian Airways", "Apply", "2025-04-05"});
        tableModel.addRow(new Object[]{"Loreal's Receipent", "Denied", "2025-01-07"});
        tableModel.addRow(new Object[]{"Amazon", "Deneid", "2025-01-21"});
        tableModel.addRow(new Object[]{"NIC", "Deneid", "2025-02-10"});
        tableModel.addRow(new Object[]{"Uber", "Apply", "2025-05-19"});
        tableModel.addRow(new Object[]{"Oracle", "Deneid", "2025-02-22"});
        tableModel.addRow(new Object[]{"ISRO", "Apply", "2025-03-27"});
        tableModel.addRow(new Object[]{"J.P. Morgan", "Apply", "2025-06-04"});
        tableModel.addRow(new Object[]{"Infosys", "Apply", "2025-05-11"});
        tableModel.addRow(new Object[]{"BSF", "Deneid", "2025-03-22"});
        tableModel.addRow(new Object[]{"Indian Navy", "Apply", "2025-04-23"});
        tableModel.addRow(new Object[]{"NIA", "Apply", "2025-04-16"});
        

        // Input and Action Panel
        JPanel actionPanel = new JPanel(new GridLayout(1, 3, 10, 10));

        // Search Feature
        JLabel searchLabel = new JLabel("Search by Company or Status:");
        searchField = new JTextField();
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(new SearchButtonListener());

        actionPanel.add(searchLabel);
        actionPanel.add(searchField);
        actionPanel.add(searchButton);

        // Reminder Feature
        JButton reminderButton = new JButton("Show Latest Applications");
        reminderButton.addActionListener(new ReminderButtonListener());
        actionPanel.add(reminderButton);

        // Adding Components
        add(scrollPane, BorderLayout.CENTER);
        add(actionPanel, BorderLayout.SOUTH);
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(70, 130, 180)); // Steel Blue
        JLabel footerLabel = new JLabel("© 2025 Job Application Tracker. All Rights Reserved.", JLabel.CENTER);
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);
        add(footerPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private class SearchButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String searchText = searchField.getText().trim().toLowerCase();
            if (searchText.isEmpty()) {
                JOptionPane.showMessageDialog(TotalApplications1.this,
                        "Please enter a search term.", "Search Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Filter logic
            DefaultTableModel filteredModel = new DefaultTableModel(
                    new String[]{"Company Name", "Status", "Last Date to Apply"}, 0);

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String company = tableModel.getValueAt(i, 0).toString().toLowerCase();
                String status = tableModel.getValueAt(i, 1).toString().toLowerCase();

                if (company.contains(searchText) || status.contains(searchText)) {
                    filteredModel.addRow(new Object[]{
                            tableModel.getValueAt(i, 0),
                            tableModel.getValueAt(i, 1),
                            tableModel.getValueAt(i, 2)
                    });
                }
            }

            applicationTable.setModel(filteredModel);
        }
    }

    private class ReminderButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            StringBuilder reminderMessage = new StringBuilder("Upcoming Deadlines:\n");
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String company = tableModel.getValueAt(i, 0).toString();
                String date = tableModel.getValueAt(i, 2).toString();
                reminderMessage.append(company).append(" - Apply by ").append(date).append("\n");
            }
            JOptionPane.showMessageDialog(TotalApplications1.this,
                    reminderMessage.toString(), "Reminders", JOptionPane.INFORMATION_MESSAGE);
        }
    
    }
         public static void main(String[] args) {
        new TotalApplications1();

    }
}