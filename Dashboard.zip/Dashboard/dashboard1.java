package com.mycompany.sample;

import javax.swing.*;
import java.awt.*;
public class Sample extends JFrame {
    public Sample(){
         
         setTitle("Job Application Tracker - Dashboard");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180)); // Steel Blue
        JLabel headerLabel = new JLabel("Dashboard");
        headerLabel.setFont(new Font("Serif", Font.BOLD, 36));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Left Sidebar
        JPanel sidebarPanel = new JPanel();
        sidebarPanel.setLayout(new GridLayout(5, 1, 10, 10));
        sidebarPanel.setBackground(new Color(240, 240, 240)); // Light gray
       
       String[] menuItems = {"Dashboard", "Add Application", "View Applications", "Tasks", "Settings"};
        for (String item : menuItems) {
            JButton button = new JButton(item);

            // Highlight the Dashboard button
             if (item.equals("Dashboard")) {
        button.setBackground(new Color(70, 130, 180)); // Steel Blue
        button.setForeground(Color.WHITE);
        button.setFont(new Font("SansSerif", Font.BOLD, 16));
        
        // Shadow border effect
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 3, 6, 3, new Color(50, 50, 50)), // Shadow effect
                BorderFactory.createEmptyBorder(10, 15, 10, 15) // Padding
        ));}else {
                button.setBackground(Color.WHITE);
                button.setForeground(Color.BLACK);
            }

            button.setFocusPainted(false);
            button.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
            button.addActionListener(e -> {
                JOptionPane.showMessageDialog(this, "Clicked: " + item);
            });
            sidebarPanel.add(button);
        }
        add(sidebarPanel, BorderLayout.WEST);

        // Main Content Area
        JPanel mainContentPanel = new JPanel();
        mainContentPanel.setLayout(new GridLayout(2, 2, 10, 10));
        mainContentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Overview Cards
      /*  String[] cardTitles = {"Total Applications", "Pending Applications", "Successful Applications", "Rejected Applications"};
        for (String title : cardTitles) {
            JPanel card = new JPanel();
            card.setLayout(new BorderLayout());
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
            JLabel cardLabel = new JLabel(title, JLabel.CENTER);
            cardLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
            card.add(cardLabel, BorderLayout.CENTER);
            mainContentPanel.add(card);
        }
        add(mainContentPanel, BorderLayout.CENTER);*/
       String[] cardTitles = {"Total Applications", "Pending Applications", "Successful Applications", "Rejected Applications"};
        for (String title : cardTitles) {
            JButton cardButton = new JButton(title);
            cardButton.setFont(new Font("SansSerif", Font.BOLD, 18));
            cardButton.setBackground(Color.WHITE);
            cardButton.setForeground(new Color(70, 130, 180)); // Steel Blue text
            cardButton.setFocusPainted(false);
            cardButton.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 2));

            // Add hover effect
            cardButton.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    cardButton.setBackground(new Color(230, 230, 230)); // Light hover effect
                }

                @Override
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    cardButton.setBackground(Color.WHITE); // Reset to default
                }
            });

            cardButton.addActionListener(e -> {
                JOptionPane.showMessageDialog(this, "Clicked: " + title);
            });

            mainContentPanel.add(cardButton);
        }
        add(mainContentPanel, BorderLayout.CENTER);



        // Footer Panel
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(70, 130, 180)); // Steel Blue
        JLabel footerLabel = new JLabel("© 2025 Job Application Tracker. All Rights Reserved.", JLabel.CENTER);
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);
        add(footerPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        new Sample();
        
   
    }
}